from flask import Blueprint, render_template
from ..auth.routes import login_required, current_user
from ..models import ITI, Trade, Lab, User

dashboard_bp = Blueprint("dashboard", __name__)

@dashboard_bp.route("/")
@login_required
def index():
    user = current_user()

    if user.role == "developer":
        context = {
            "title": "Developer Dashboard",
            "iti_count": ITI.query.count(),
            "trade_count": Trade.query.count(),
            "lab_count": Lab.query.count(),
            "user_count": User.query.count(),
        }
    else:
        iti = user.iti
        context = {
            "title": "ITI Dashboard",
            "iti": iti,
            "trade_count": len(iti.trades) if iti else 0,
            "lab_count": len(iti.labs) if iti else 0,
            "user_count": User.query.filter_by(iti_id=iti.id).count() if iti else 0,
        }

    return render_template("dashboard/index.html", **context)
