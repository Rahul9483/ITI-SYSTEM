from flask import Blueprint, render_template
from ..auth.routes import role_required
from ..models import ITI, Trade, Lab, User

developer_bp = Blueprint("developer", __name__, url_prefix="/developer")

@developer_bp.route("/")
@role_required("developer")
def index():
    return render_template(
        "developer/index.html",
        itis=ITI.query.order_by(ITI.name).all(),
        trades=Trade.query.order_by(Trade.name).all(),
        labs=Lab.query.order_by(Lab.name).all(),
        users=User.query.order_by(User.name).all()
    )
