from flask import Blueprint, render_template
from ..auth.routes import role_required, current_user

teacher_bp = Blueprint("teacher", __name__, url_prefix="/teacher")

@teacher_bp.route("/")
@role_required("teacher")
def index():
    return render_template("teacher/index.html", iti=current_user().iti)
