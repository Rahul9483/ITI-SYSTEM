from ..extensions import db

class Lab(db.Model):
    __tablename__ = "labs"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    iti_id = db.Column(db.Integer, db.ForeignKey("itis.id"), nullable=False, index=True)
    trade_id = db.Column(db.Integer, db.ForeignKey("trades.id"), nullable=True, index=True)
    active = db.Column(db.Boolean, default=True, nullable=False)

    iti = db.relationship("ITI", back_populates="labs")
    trade = db.relationship("Trade", back_populates="labs")
