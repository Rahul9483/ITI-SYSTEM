from datetime import datetime, timezone
from ..extensions import db

class ITI(db.Model):
    __tablename__ = "itis"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    address = db.Column(db.String(300))
    district = db.Column(db.String(100))
    state = db.Column(db.String(100))
    pin = db.Column(db.String(10))
    phone = db.Column(db.String(30))
    email = db.Column(db.String(255))
    website = db.Column(db.String(255))
    logo = db.Column(db.String(255))
    active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    users = db.relationship("User", back_populates="iti")
    trades = db.relationship("Trade", secondary="iti_trades", back_populates="itis")
    labs = db.relationship("Lab", back_populates="iti")
