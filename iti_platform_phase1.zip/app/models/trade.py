from ..extensions import db

iti_trades = db.Table(
    "iti_trades",
    db.Column("iti_id", db.Integer, db.ForeignKey("itis.id"), primary_key=True),
    db.Column("trade_id", db.Integer, db.ForeignKey("trades.id"), primary_key=True)
)

class Trade(db.Model):
    __tablename__ = "trades"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    active = db.Column(db.Boolean, default=True, nullable=False)

    itis = db.relationship("ITI", secondary=iti_trades, back_populates="trades")
    labs = db.relationship("Lab", back_populates="trade")
