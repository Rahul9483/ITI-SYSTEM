from flask import Flask
from config import Config
from .extensions import db

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)

    from .auth.routes import auth_bp
    from .dashboard.routes import dashboard_bp
    from .developer.routes import developer_bp
    from .admin.routes import admin_bp
    from .teacher.routes import teacher_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(developer_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(teacher_bp)

    from .models import User, ITI, Trade, Lab
    with app.app_context():
        db.create_all()
        seed_initial_data()

    return app

def seed_initial_data():
    from .models import User, ITI, Trade, Lab
    from werkzeug.security import generate_password_hash

    if not User.query.filter_by(email="developer@system.local").first():
        db.session.add(User(
            name="Platform Developer",
            email="developer@system.local",
            password_hash=generate_password_hash("ChangeMe123!"),
            role="developer",
            iti_id=None
        ))

    iti = ITI.query.filter_by(code="GITIK").first()
    if not iti:
        iti = ITI(
            name="Government ITI Kankrej",
            code="GITIK",
            address="Kankrej, Banaskantha, Gujarat",
            district="Banaskantha",
            state="Gujarat",
            active=True
        )
        db.session.add(iti)
        db.session.flush()

    copa = Trade.query.filter_by(code="COPA").first()
    if not copa:
        copa = Trade(name="Computer Operator and Programming Assistant", code="COPA", active=True)
        db.session.add(copa)
        db.session.flush()
        iti.trades.append(copa)

    if not Lab.query.filter_by(iti_id=iti.id, name="COPA Computer Lab").first():
        db.session.add(Lab(name="COPA Computer Lab", iti_id=iti.id, trade_id=copa.id, active=True))

    if not User.query.filter_by(email="admin@kankrej.iti.local").first():
        db.session.add(User(
            name="Kankrej ITI Admin",
            email="admin@kankrej.iti.local",
            password_hash=generate_password_hash("ChangeMe123!"),
            role="iti_admin",
            iti_id=iti.id
        ))

    if not User.query.filter_by(email="teacher@kankrej.iti.local").first():
        db.session.add(User(
            name="COPA Teacher",
            email="teacher@kankrej.iti.local",
            password_hash=generate_password_hash("ChangeMe123!"),
            role="teacher",
            iti_id=iti.id
        ))

    db.session.commit()
