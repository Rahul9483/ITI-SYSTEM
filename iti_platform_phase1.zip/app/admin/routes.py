from flask import Blueprint, render_template
from ..auth.routes import role_required, current_user

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

@admin_bp.route("/")
@role_required("iti_admin")
def index():
    return render_template("admin/index.html", iti=current_user().iti)
