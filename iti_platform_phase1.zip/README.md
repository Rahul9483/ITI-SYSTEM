# ITI Multi-Trade Management Platform — Phase 1

Phase 1 provides:
- Multi-ITI foundation
- Developer, ITI Admin and Teacher roles
- Server-side authorization
- ITI data isolation
- ITI/trade/lab foundation
- COPA seed data for Government ITI Kankrej
- Responsive Bootstrap dashboard
- SQLite initially, with DATABASE_URL support for future PostgreSQL migration

## Run

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python run.py
```

Open http://127.0.0.1:5000

## Demo accounts

- Developer: developer@system.local / ChangeMe123!
- ITI Admin: admin@kankrej.iti.local / ChangeMe123!
- Teacher: teacher@kankrej.iti.local / ChangeMe123!

Change these passwords before any real deployment.
